package com.netcracker.bloodbank.dataAccess.models;

public enum Type {
    Donor,Receiver
}
